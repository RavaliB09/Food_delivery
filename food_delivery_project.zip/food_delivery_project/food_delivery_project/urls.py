from django.contrib import admin
from django.urls import path, include
from pricing.views import calculate_price

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', calculate_price, name='calculate_price'),  # Redirect root URL to calculate_price endpoint
    path('api/calculate_price/', calculate_price, name='calculate_price'),
]
