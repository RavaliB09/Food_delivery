from django.http import HttpResponse
from django.views import View
from django.shortcuts import render
def calculate_price(request):
    # Sample input
    zone = request.GET.get('zone')
    organization_id = request.GET.get('organization_id')
    total_distance = float(request.GET.get('total_distance'))
    item_type = request.GET.get('item_type')

    # Sample calculation logic (replace with actual logic)
    base_price = 10
    per_km_price = 1.5 if item_type == 'perishable' else 1
    total_price = base_price + (total_distance - 5) * per_km_price if total_distance > 5 else base_price

    return HttpResponse({'total_price': total_price})
